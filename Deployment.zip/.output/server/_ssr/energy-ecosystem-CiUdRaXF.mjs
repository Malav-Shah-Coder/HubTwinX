import { n as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { F as Activity, M as Battery, N as BatteryCharging, O as Building2, S as Fan, d as Plug, h as Lightbulb, i as TriangleAlert, m as Menu, o as Thermometer, p as Moon, s as Sun, t as X, x as Gauge } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/energy-ecosystem-CiUdRaXF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		label: "Platform",
		href: "#platform"
	},
	{
		label: "Capabilities",
		href: "#capabilities"
	},
	{
		label: "Technology",
		href: "#technology"
	},
	{
		label: "Applications",
		href: "#applications"
	},
	{
		label: "PowerTwinX",
		href: "#powertwinx"
	},
	{
		label: "About",
		href: "#about"
	}
];
function Nav() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [isLight, setIsLight] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const isLightStored = localStorage.getItem("theme") === "light";
		setIsLight(isLightStored);
		if (isLightStored) document.documentElement.classList.add("light-theme");
		else document.documentElement.classList.remove("light-theme");
	}, []);
	const toggleTheme = () => {
		setIsLight((prev) => {
			const next = !prev;
			if (next) {
				document.documentElement.classList.add("light-theme");
				localStorage.setItem("theme", "light");
			} else {
				document.documentElement.classList.remove("light-theme");
				localStorage.setItem("theme", "dark");
			}
			return next;
		});
	};
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: `fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "border-b border-border bg-background/85 backdrop-blur-xl" : "border-b border-transparent bg-transparent"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
			className: "mx-auto flex max-w-7xl items-center justify-between gap-6 px-5 py-4 lg:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#top",
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/hubtwinx.png",
						alt: "HubTwinX by EnerSpace Technology LLP",
						width: 300,
						height: 53,
						className: "h-11 w-auto"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden items-center gap-8 lg:flex",
					children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: l.href,
						className: "text-sm font-medium text-muted-foreground transition-colors hover:text-foreground",
						children: l.label
					}, l.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: toggleTheme,
							"aria-label": "Toggle theme",
							className: "rounded-full border border-border p-2 text-foreground transition-colors hover:bg-secondary/50",
							children: isLight ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contact",
							className: "hidden rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-transform duration-300 hover:scale-[1.03] sm:inline-flex",
							style: { backgroundImage: "var(--gradient-brand)" },
							children: "Book a Demo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Toggle navigation",
							onClick: () => setOpen((v) => !v),
							className: "rounded-full border border-border p-2 text-foreground lg:hidden",
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						})
					]
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border bg-background/95 px-5 py-4 backdrop-blur-xl lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-1",
				children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: l.href,
					onClick: () => setOpen(false),
					className: "block rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground",
					children: l.label
				}) }, l.href))
			})
		})]
	});
}
function Reveal({ children, delay = 0, className = "", as: Tag = "div" }) {
	const ref = (0, import_react.useRef)(null);
	const [visible, setVisible] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => {
			for (const e of entries) if (e.isIntersecting) {
				setVisible(true);
				io.disconnect();
			}
		}, {
			threshold: .15,
			rootMargin: "0px 0px -60px 0px"
		});
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, {
		ref,
		className: `reveal ${visible ? "is-visible" : ""} ${className}`,
		style: { animationDelay: `${delay}ms` },
		children
	});
}
var layers = [
	{
		id: "site",
		title: "Site",
		items: [
			"Building",
			"Factory",
			"Hospital",
			"Hotel",
			"Office",
			"Campus",
			"Home"
		]
	},
	{
		id: "infrastructure",
		title: "Infrastructure",
		items: [
			"HT / LT",
			"Transformers",
			"Panels",
			"DBs",
			"Cables",
			"Meters"
		]
	},
	{
		id: "energy",
		title: "Energy",
		items: [
			"Grid",
			"Solar",
			"Battery",
			"Generator",
			"EV",
			"Loads"
		]
	},
	{
		id: "equipment",
		title: "Equipment",
		items: [
			"HVAC",
			"Pumps",
			"Motors",
			"Machines",
			"Elevators",
			"Critical equipment"
		]
	},
	{
		id: "environment",
		title: "Environment",
		items: [
			"Temperature",
			"Humidity",
			"Air quality",
			"Occupancy",
			"Sensors"
		]
	},
	{
		id: "operations",
		title: "Operations",
		items: [
			"Schedules",
			"Alerts",
			"Automation",
			"Maintenance",
			"Analytics"
		]
	}
];
function TwinLayers() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
		className: "relative mt-12 space-y-4 border-l border-border pl-6 sm:pl-10",
		children: layers.map((layer, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
			as: "li",
			delay: i * 60,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "surface-panel relative p-5 sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -left-[47px] top-8 hidden size-3 rounded-full sm:block",
						style: { backgroundImage: "var(--gradient-brand)" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-sm text-brand-cyan",
							children: String(i + 1).padStart(2, "0")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-2xl font-semibold sm:text-3xl",
							children: layer.title
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-wrap gap-2",
						children: layer.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-full border border-border bg-secondary/40 px-3.5 py-1.5 text-sm text-muted-foreground",
							children: item
						}, item))
					})
				]
			})
		}, layer.id))
	});
}
var tiles = [
	{
		label: "Energy consumption",
		icon: Activity,
		meta: "Site • live"
	},
	{
		label: "Solar generation",
		icon: Sun,
		meta: "On-site generation"
	},
	{
		label: "Battery storage",
		icon: Battery,
		meta: "Charge / discharge"
	},
	{
		label: "Environment",
		icon: Thermometer,
		meta: "Temperature • humidity • air"
	},
	{
		label: "Spaces & rooms",
		icon: Building2,
		meta: "Floors • zones • areas"
	},
	{
		label: "Alerts",
		icon: TriangleAlert,
		meta: "Conditions needing attention"
	}
];
var bars = [
	34,
	52,
	41,
	68,
	57,
	76,
	62,
	88,
	71,
	59,
	66,
	45
];
function TwinDashboard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "surface-panel overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-4 sm:px-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-brand-green pulse-node" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm tracking-wide",
					children: "HubTwinX™ Site Environment"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2 text-xs text-muted-foreground",
				children: [
					"Energy",
					"Infrastructure",
					"Equipment",
					"Environment",
					"Operations"
				].map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `rounded-full border px-3 py-1 ${i === 0 ? "border-primary/60 text-foreground" : "border-border"}`,
					children: t
				}, t))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-5 p-5 sm:p-7 lg:grid-cols-[1.4fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-secondary/30 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Consumption pattern"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex h-44 items-end gap-2",
						children: bars.map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 rounded-t-sm",
							style: {
								height: `${h}%`,
								backgroundImage: "var(--gradient-brand)",
								opacity: .35 + h / 100 * .65
							}
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted-foreground",
						children: "Illustrative view of how consumption, generation and equipment behaviour appear inside one digital environment."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2",
				children: tiles.map((t) => {
					const Icon = t.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-xl border border-border bg-secondary/30 p-4 transition-colors hover:border-primary/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-brand-cyan" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm font-semibold",
								children: t.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: t.meta
							})
						]
					}, t.label);
				})
			})]
		})]
	});
}
var systems = [
	{
		key: "lighting",
		label: "Lighting",
		icon: Lightbulb,
		onLabel: "Zones active",
		offLabel: "Zones off",
		note: "Switch lighting zones on or off across floors and areas."
	},
	{
		key: "hvac",
		label: "HVAC",
		icon: Fan,
		onLabel: "Cooling active",
		offLabel: "Standby",
		note: "Adjust HVAC operation based on conditions and schedules."
	},
	{
		key: "battery",
		label: "Battery",
		icon: BatteryCharging,
		onLabel: "Discharging to site",
		offLabel: "Idle",
		note: "Change how stored energy supports the site."
	},
	{
		key: "ev",
		label: "EV Charging",
		icon: Plug,
		onLabel: "Charging",
		offLabel: "Paused",
		note: "Manage charging points and charging state."
	},
	{
		key: "solar",
		label: "Solar",
		icon: Sun,
		onLabel: "Exporting to site",
		offLabel: "Curtailed",
		note: "See and manage on-site generation."
	},
	{
		key: "equipment",
		label: "Equipment",
		icon: Gauge,
		onLabel: "Running",
		offLabel: "Stopped",
		note: "Monitor critical equipment and respond to alerts."
	}
];
function ControlRoom() {
	const [state, setState] = (0, import_react.useState)({
		lighting: true,
		hvac: true,
		battery: false,
		ev: true,
		solar: true,
		equipment: true
	});
	const [active, setActive] = (0, import_react.useState)("lighting");
	const activeSystem = systems.find((s) => s.key === active);
	const activeCount = Object.values(state).filter(Boolean).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1fr_1.15fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-panel p-5 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Site control"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 text-xl font-semibold",
					children: "Connected systems"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 grid gap-3 sm:grid-cols-2",
					children: systems.map((s) => {
						const on = state[s.key];
						const Icon = s.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onMouseEnter: () => setActive(s.key),
							onFocus: () => setActive(s.key),
							onClick: () => {
								setActive(s.key);
								setState((p) => ({
									...p,
									[s.key]: !p[s.key]
								}));
							},
							className: `group w-full rounded-xl border p-4 text-left transition-all duration-300 ${active === s.key ? "border-primary/60 bg-secondary/70 glow-brand" : "border-border bg-secondary/30 hover:border-primary/40"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `size-5 transition-colors ${on ? "text-brand-cyan" : "text-muted-foreground"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `h-5 w-9 rounded-full p-0.5 transition-colors ${on ? "bg-brand-green/70" : "bg-muted"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block size-4 rounded-full bg-foreground transition-transform duration-300 ${on ? "translate-x-4" : ""}` })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm font-semibold",
									children: s.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: on ? s.onLabel : s.offLabel
								})
							]
						}) }, s.key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-sm text-muted-foreground",
					children: activeSystem.note
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "surface-panel relative overflow-hidden p-5 sm:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Digital twin"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 text-xl font-semibold",
						children: "Live site view"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-full border border-border px-3 py-1 text-xs text-muted-foreground",
						children: [activeCount, "/6 systems active"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 520 340",
					className: "mt-4 w-full",
					role: "img",
					"aria-label": "Interactive site digital twin",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
							id: "ctrlEdge",
							x1: "0",
							y1: "0",
							x2: "1",
							y2: "1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "0%",
									stopColor: "oklch(0.55 0.16 253)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "55%",
									stopColor: "oklch(0.73 0.13 205)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
									offset: "100%",
									stopColor: "oklch(0.72 0.19 148)"
								})
							]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							stroke: "url(#ctrlEdge)",
							fill: "none",
							strokeWidth: "1.4",
							opacity: "0.85",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M120 250 L120 120 L260 60 L400 120 L400 250 L260 300 Z" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M120 120 L260 180 L400 120" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M260 180 L260 300" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M120 185 L260 240 L400 185" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
							opacity: state.solar ? 1 : .25,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M200 92 L262 68 L318 92 L258 116 Z",
								fill: "oklch(0.55 0.16 253 / 45%)",
								stroke: "url(#ctrlEdge)"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
							opacity: state.lighting ? 1 : .18,
							children: [
								[160, 170],
								[210, 190],
								[300, 195],
								[355, 175],
								[230, 145],
								[300, 145]
							].map(([x, y]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: x,
								cy: y,
								r: "6",
								fill: "oklch(0.83 0.19 128 / 65%)",
								className: "pulse-node"
							}, `${x}-${y}`))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							opacity: state.hvac ? 1 : .22,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "330",
								y: "96",
								width: "46",
								height: "26",
								rx: "5",
								fill: "oklch(0.73 0.13 205 / 35%)",
								stroke: "url(#ctrlEdge)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "353",
								cy: "109",
								r: "7",
								fill: "none",
								stroke: "oklch(0.73 0.13 205)",
								className: state.hvac ? "pulse-node" : ""
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							opacity: state.battery ? 1 : .25,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "66",
								y: "228",
								width: "40",
								height: "52",
								rx: "6",
								fill: "oklch(0.72 0.19 148 / 25%)",
								stroke: "url(#ctrlEdge)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "74",
								y: state.battery ? 244 : 262,
								width: "24",
								height: state.battery ? 28 : 10,
								rx: "3",
								fill: "oklch(0.72 0.19 148 / 70%)"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							opacity: state.ev ? 1 : .25,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "424",
								y: "236",
								width: "26",
								height: "44",
								rx: "6",
								fill: "oklch(0.55 0.16 253 / 35%)",
								stroke: "url(#ctrlEdge)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "437",
								cy: "252",
								r: "5",
								fill: "oklch(0.73 0.13 205)",
								className: state.ev ? "pulse-node" : ""
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							opacity: state.equipment ? 1 : .25,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: "188",
								y: "248",
								width: "140",
								height: "34",
								rx: "6",
								fill: "oklch(0.55 0.16 253 / 22%)",
								stroke: "url(#ctrlEdge)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "206",
								cy: "265",
								r: "5",
								fill: "oklch(0.83 0.19 128)",
								className: state.equipment ? "pulse-node" : ""
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
							stroke: "url(#ctrlEdge)",
							strokeWidth: "1.6",
							fill: "none",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M106 254 L188 262",
									className: state.battery ? "flow-line" : "",
									opacity: state.battery ? 1 : .2
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M328 262 L424 258",
									className: state.ev ? "flow-line" : "",
									opacity: state.ev ? 1 : .2
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
									d: "M258 116 L258 178",
									className: state.solar ? "flow-line" : "",
									opacity: state.solar ? 1 : .2
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Select a system to see how visibility turns into action. This is an illustrative representation of the HubTwinX™ control layer."
				})
			]
		})]
	});
}
var hero_digital_twin_default = "/assets/hero-digital-twin-BHPgabjV.jpg";
var grid_to_site_default = "/assets/grid-to-site-f19cek5J.jpg";
var control_room_default = "/assets/control-room-Dg7REq6t.jpg";
var vision_default = "/assets/vision-DA5mqRIz.jpg";
var industrial_twin_default = "/assets/industrial-twin-CVtcagBz.jpg";
var energy_ecosystem_default = "/assets/energy-ecosystem-B04hnANP.jpg";
//#endregion
export { TwinLayers as a, grid_to_site_default as c, vision_default as d, TwinDashboard as i, hero_digital_twin_default as l, Nav as n, control_room_default as o, Reveal as r, energy_ecosystem_default as s, ControlRoom as t, industrial_twin_default as u };
