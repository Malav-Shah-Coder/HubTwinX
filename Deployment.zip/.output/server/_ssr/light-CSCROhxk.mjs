import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as Boxes, C as Factory, D as Building, E as ChartLine, P as ArrowRight, T as Cpu, _ as Layers, a as Timer, b as GraduationCap, c as Stethoscope, f as Network, g as Leaf, j as Bolt, k as Brain, l as ShieldCheck, n as Wrench, r as Workflow, s as Sun, u as Radio, v as House, w as Eye, x as Gauge, y as Hotel } from "../_libs/lucide-react.mjs";
import { a as TwinLayers, c as grid_to_site_default, d as vision_default, i as TwinDashboard, l as hero_digital_twin_default, n as Nav, o as control_room_default, r as Reveal, s as energy_ecosystem_default, t as ControlRoom, u as industrial_twin_default } from "./energy-ecosystem-CiUdRaXF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/light-CSCROhxk.js
var import_jsx_runtime = require_jsx_runtime();
function SectionHeading({ eyebrow, title, copy, align = "left" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: align === "center" ? "mx-auto max-w-3xl text-center" : "max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "eyebrow",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 text-3xl font-semibold leading-[1.05] sm:text-5xl",
				children: title
			}),
			copy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-base leading-relaxed text-muted-foreground sm:text-lg",
				children: copy
			})
		]
	});
}
var scrollStory = [
	{
		n: "01",
		t: "Power arrives",
		d: "The site receives energy."
	},
	{
		n: "02",
		t: "The site becomes visible",
		d: "Meters, systems, assets and spaces are digitally represented."
	},
	{
		n: "03",
		t: "Everything connects",
		d: "IoT connects the physical environment."
	},
	{
		n: "04",
		t: "The digital twin forms",
		d: "The physical site gets a digital representation."
	},
	{
		n: "05",
		t: "Intelligence emerges",
		d: "AI and analytics identify patterns and opportunities."
	},
	{
		n: "06",
		t: "Decisions become action",
		d: "Users can monitor and control connected systems."
	},
	{
		n: "07",
		t: "Automation takes over",
		d: "Rules and workflows can trigger predefined actions."
	},
	{
		n: "08",
		t: "The site becomes intelligent",
		d: "Energy, assets and operations become visible, understandable and actionable."
	}
];
var capabilities = [
	{
		icon: Bolt,
		t: "Energy Management",
		d: "Understand where, when and how energy is being consumed."
	},
	{
		icon: Boxes,
		t: "Asset Management",
		d: "Know important assets, their location, condition and operational status."
	},
	{
		icon: Building,
		t: "Facility Management",
		d: "Bring building systems into one digital environment."
	},
	{
		icon: Wrench,
		t: "Predictive Maintenance",
		d: "Identify abnormal behaviour before it becomes a major problem."
	},
	{
		icon: Workflow,
		t: "Automation",
		d: "Create intelligent rules and workflows for connected systems."
	},
	{
		icon: Leaf,
		t: "Sustainability",
		d: "Measure and optimize energy performance, renewable generation and consumption."
	}
];
var applications = [
	{
		icon: House,
		t: "Residential",
		d: "Smart homes, villas, apartments"
	},
	{
		icon: Building,
		t: "Commercial",
		d: "Offices, malls, retail, commercial buildings"
	},
	{
		icon: Factory,
		t: "Industrial",
		d: "Factories, plants, warehouses, production facilities"
	},
	{
		icon: Stethoscope,
		t: "Healthcare",
		d: "Hospitals, clinics and healthcare campuses"
	},
	{
		icon: Hotel,
		t: "Hospitality",
		d: "Hotels, resorts and restaurants"
	},
	{
		icon: GraduationCap,
		t: "Institutional",
		d: "Schools, universities and campuses"
	},
	{
		icon: Sun,
		t: "Energy",
		d: "Solar, battery, EV charging and distributed energy sites"
	}
];
var whyItems = [
	{
		icon: Eye,
		t: "One View",
		d: "Bring disconnected systems into one digital environment."
	},
	{
		icon: Radio,
		t: "Real-Time",
		d: "Understand what is happening now."
	},
	{
		icon: Brain,
		t: "Intelligent",
		d: "Turn operational data into actionable insights."
	},
	{
		icon: Network,
		t: "Connected",
		d: "Connect meters, sensors, assets and equipment."
	},
	{
		icon: Layers,
		t: "Scalable",
		d: "Start with energy and expand to the entire site."
	},
	{
		icon: Gauge,
		t: "Control",
		d: "Move beyond monitoring to intelligent action."
	},
	{
		icon: ShieldCheck,
		t: "Future Ready",
		d: "Built for AI, automation, distributed energy and smart infrastructure."
	}
];
var workflows = [
	{
		tag: "Environment",
		steps: [
			["Condition", "Temperature rises"],
			["Intelligence", "HubTwinX identifies the condition"],
			["Rule", "If temperature exceeds a defined threshold"],
			["Action", "Adjust HVAC"],
			["Result", "Optimized environment"]
		]
	},
	{
		tag: "Energy",
		steps: [
			["Condition", "High demand detected"],
			["Intelligence", "Demand pattern identified"],
			["Rule", "If demand exceeds a defined threshold"],
			["Action", "Intelligent response to optimize load"],
			["Result", "Balanced consumption"]
		]
	},
	{
		tag: "Lighting",
		steps: [
			["Condition", "Occupancy detected"],
			["Intelligence", "Space usage understood"],
			["Rule", "If a space is occupied or vacant"],
			["Action", "Lighting response"],
			["Result", "Efficient operation"]
		]
	},
	{
		tag: "Equipment",
		steps: [
			["Condition", "Abnormal behaviour"],
			["Intelligence", "Deviation identified"],
			["Rule", "If behaviour falls outside expected operation"],
			["Action", "Alert raised"],
			["Result", "Maintenance response"]
		]
	}
];
var architecture = [
	{
		t: "Physical Site",
		d: "Meters • Sensors • Equipment • Assets"
	},
	{
		t: "Connectivity",
		d: "IoT • Edge Devices • Gateways • Communication"
	},
	{
		t: "HubTwinX Digital Twin",
		d: "Site • Floors • Rooms • Assets • Energy • Equipment"
	},
	{
		t: "Intelligence",
		d: "Analytics • AI • Alerts • Prediction • Optimization"
	},
	{
		t: "Action",
		d: "Monitor • Control • Automate • Optimize"
	}
];
function LightHubTwinX() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		className: "overflow-x-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative isolate overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-28",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-hidden": true,
						className: "pointer-events-none absolute inset-0 -z-10 opacity-70",
						style: { background: "radial-gradient(1000px 620px at 78% 18%, oklch(0.55 0.16 253 / 28%), transparent 65%), radial-gradient(760px 540px at 12% 78%, oklch(0.72 0.19 148 / 16%), transparent 70%)" }
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-[1.02fr_1fr] lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "eyebrow",
								children: "Digital Twin platform • EnerSpace Technology LLP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "mt-5 font-display text-[2.6rem] font-bold leading-[0.98] sm:text-6xl xl:text-6xl",
								children: [
									"YOUR ENTIRE HUB.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gradient-brand",
										children: "ONE DIGITAL VIEW."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground",
								children: "HubTwinX™ transforms your home, office, factory, hospital, hotel, campus or commercial facility into an intelligent Digital Twin."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-xl text-base leading-relaxed text-muted-foreground",
								children: "See your energy, assets, equipment, spaces and connected systems in one unified digital environment — and monitor, analyze and control them from a single interface."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-9 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "#platform",
									className: "inline-flex items-center gap-2 rounded-full px-7 py-3.5 font-semibold text-primary-foreground transition-transform duration-300 hover:scale-[1.03]",
									style: { backgroundImage: "var(--gradient-brand)" },
									children: ["Explore HubTwinX ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#contact",
									className: "inline-flex items-center gap-2 rounded-full border border-border px-7 py-3.5 font-semibold transition-colors hover:border-primary/60 hover:bg-secondary/50",
									children: "Book a Demo"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-10 font-display text-sm tracking-[0.2em] text-muted-foreground",
								children: "POWER REACHES THE SITE. HUBTWINX MAKES THE SITE INTELLIGENT."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 120,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "surface-panel overflow-hidden p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: hero_digital_twin_default,
									alt: "A modern facility transitioning from a physical building into a digital twin with energy and equipment data layers",
									width: 1600,
									height: 1104,
									className: "w-full rounded-xl"
								})
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-y border-border bg-secondary/20 py-16 sm:py-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "The journey",
							title: "Power → Meter → Site → Intelligence → Action",
							copy: "One continuous story: from the moment energy reaches your site to the moment your site starts operating intelligently."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: scrollStory.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								as: "li",
								delay: i * 50,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "h-full rounded-xl border border-border bg-card/60 p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-display text-sm text-brand-cyan",
											children: s.n
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 font-display text-base font-semibold uppercase tracking-wide",
											children: s.t
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed text-muted-foreground",
											children: s.d
										})
									]
								})
							}, s.n))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "platform",
					className: "scroll-mt-24 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-7xl gap-14 px-5 lg:grid-cols-2 lg:items-center lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "What is HubTwinX",
							title: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "YOUR SITE, DIGITALLY CONNECTED." }),
							copy: "Facilities contain many interconnected elements — electrical panels, meters, HVAC, lighting, solar, batteries, EV chargers, machines, rooms, equipment and sensors. Traditionally, these systems operate through separate applications and disconnected controls. HubTwinX brings them together."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 space-y-4",
							children: [
								"What you have physically, you can see digitally.",
								"What you see digitally, you can understand intelligently.",
								"What you understand, you can control."
							].map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 size-2 shrink-0 rounded-full",
									style: { backgroundImage: "var(--gradient-brand)" }
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-lg text-foreground/90",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-display text-brand-cyan",
											children: ["0", i + 1]
										}),
										" ",
										line
									]
								})]
							}, line))
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 100,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "surface-panel p-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Disconnected systems → one digital twin"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									viewBox: "0 0 460 380",
									className: "mt-4 w-full",
									role: "img",
									"aria-label": "Separate site systems connecting into one HubTwinX digital environment",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
											id: "connGrad",
											x1: "0",
											y1: "0",
											x2: "460",
											y2: "380",
											gradientUnits: "userSpaceOnUse",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "0%",
													stopColor: "oklch(0.55 0.16 253)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "60%",
													stopColor: "oklch(0.73 0.13 205)"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
													offset: "100%",
													stopColor: "oklch(0.72 0.19 148)"
												})
											]
										}) }),
										[
											[
												"Panels",
												60,
												46
											],
											[
												"Meters",
												230,
												30
											],
											[
												"HVAC",
												400,
												46
											],
											[
												"Lighting",
												34,
												190
											],
											[
												"Solar",
												426,
												190
											],
											[
												"Battery",
												60,
												334
											],
											[
												"EV",
												230,
												350
											],
											[
												"Sensors",
												400,
												334
											]
										].map(([label, x, y]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
												x1: x,
												y1: y,
												x2: "230",
												y2: "190",
												stroke: "url(#connGrad)",
												strokeWidth: "1.2",
												className: "flow-line",
												opacity: "0.8"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
												cx: x,
												cy: y,
												r: "5",
												fill: "oklch(0.73 0.13 205)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
												x,
												y: y - 12,
												textAnchor: "middle",
												fill: "currentColor",
												className: "fill-muted-foreground text-[11px]",
												children: label
											})
										] }, label)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "230",
											cy: "190",
											r: "52",
											fill: "oklch(0.55 0.16 253 / 18%)",
											stroke: "url(#connGrad)",
											strokeWidth: "1.6"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
											cx: "230",
											cy: "190",
											r: "70",
											fill: "none",
											stroke: "url(#connGrad)",
											strokeWidth: "0.8",
											opacity: "0.4",
											className: "pulse-node"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("image", {
											href: "/logo-vr.png",
											x: "190",
											y: "150",
											width: "80",
											height: "80"
										})
									]
								})]
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-y border-border bg-secondary/20 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "One display",
							title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"ONE DISPLAY.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gradient-brand",
									children: "YOUR ENTIRE HUB."
								})
							] }),
							copy: "See everything from one place — energy, electrical infrastructure, solar, battery, EV charging, HVAC, lighting, machines, rooms, environmental conditions, IoT sensors and alerts."
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 120,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TwinDashboard, {})
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
								eyebrow: "Digital twin",
								title: "LAYER BY LAYER, YOUR SITE BECOMES DIGITAL.",
								copy: "Scroll through the layers of the twin — from the site itself down to the operations that keep it running."
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TwinLayers, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-10 grid gap-5 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: industrial_twin_default,
										alt: "Industrial facility with a digital twin overlay on machines and electrical systems",
										loading: "lazy",
										width: 1200,
										height: 912,
										className: "w-full rounded-2xl border border-border"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: energy_ecosystem_default,
										alt: "Solar, battery storage and EV charging connected by energy flow lines",
										loading: "lazy",
										width: 1200,
										height: 912,
										className: "w-full rounded-2xl border border-border"
									})]
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-y border-border bg-secondary/20 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "From visibility to action",
							title: "CONTROL AT YOUR FINGERTIPS.",
							copy: "HubTwinX is not only a monitoring platform. It acts as the digital control layer of the site — switch equipment on or off, control lighting, adjust HVAC, manage EV charging, optimize battery usage, manage solar energy, monitor critical equipment, set operating schedules, respond to alerts and automate predefined actions."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 flex flex-wrap items-center gap-3 font-display text-sm tracking-[0.18em]",
							children: [
								"SEE",
								"UNDERSTAND",
								"DECIDE",
								"ACT"
							].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full border border-border px-4 py-2",
									children: s
								}), i < 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-brand-cyan" })]
							}, s))
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 120,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlRoom, {})
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "technology",
					className: "scroll-mt-24 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
								eyebrow: "Technology",
								title: "FROM DATA TO DECISIONS.",
								copy: "IoT captures what is happening. The Digital Twin shows where and how it is happening. AI helps understand what it means. Automation helps take action."
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-12 grid gap-4 lg:grid-cols-4",
								children: [
									{
										icon: Radio,
										k: "IoT",
										v: "Capture"
									},
									{
										icon: Layers,
										k: "Digital Twin",
										v: "Visualize"
									},
									{
										icon: Cpu,
										k: "AI",
										v: "Understand"
									},
									{
										icon: Workflow,
										k: "Automation",
										v: "Act"
									}
								].map((s, i) => {
									const Icon = s.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
										as: "li",
										delay: i * 90,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "surface-panel relative h-full p-6",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6 text-brand-cyan" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-5 font-display text-2xl font-semibold",
													children: s.k
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 eyebrow",
													children: s.v
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "mt-6 h-px w-full",
													style: {
														backgroundImage: "var(--gradient-brand)",
														opacity: .6
													}
												})
											]
										})
									}, s.k);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-14 grid gap-10 lg:grid-cols-2 lg:items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: control_room_default,
										alt: "Digital control room with facility twin and energy flow visualizations on large screens",
										loading: "lazy",
										width: 1600,
										height: 912,
										className: "w-full rounded-2xl border border-border"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
										eyebrow: "Intelligence",
										title: "INTELLIGENCE BEHIND THE SITE.",
										copy: "HubTwinX uses connected data and intelligent analytics to help organizations understand how their site operates."
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-7 grid gap-3 sm:grid-cols-2",
										children: [
											"Unusual energy consumption",
											"Equipment abnormalities",
											"Peak demand patterns",
											"Energy wastage",
											"Operational inefficiencies",
											"Potential equipment failures",
											"Optimization opportunities"
										].map((sig) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-start gap-2.5 rounded-xl border border-border bg-secondary/30 p-3.5 text-sm text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartLine, { className: "mt-0.5 size-4 shrink-0 text-brand-green" }), sig]
										}, sig))
									})] })]
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-y border-border bg-secondary/20 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Automation",
							title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"SEE IT. UNDERSTAND IT.",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gradient-brand",
									children: "AUTOMATE IT."
								})
							] }),
							copy: "Examples of automation logic that can be expressed inside HubTwinX. These illustrate how rules and workflows are structured."
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid gap-5 lg:grid-cols-2",
							children: workflows.map((w, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: i * 80,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "surface-panel h-full p-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "eyebrow",
										children: w.tag
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
										className: "mt-5 space-y-3",
										children: w.steps.map(([k, v], idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-start gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "relative flex flex-col items-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-1.5 size-2.5 rounded-full",
													style: { backgroundImage: "var(--gradient-brand)" }
												}), idx < w.steps.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 h-8 w-px bg-border" })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block font-display text-xs uppercase tracking-[0.18em] text-brand-cyan",
												children: k
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm text-muted-foreground",
												children: v
											})] })]
										}, k))
									})]
								})
							}, w.tag))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "applications",
					className: "scroll-mt-24 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Applications",
							title: "BUILT FOR EVERY TYPE OF SITE.",
							copy: "One platform, applied across residential, commercial, industrial, healthcare, hospitality, institutional and energy sites."
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: applications.map((a, i) => {
								const Icon = a.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									as: "li",
									delay: i * 60,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "group surface-panel h-full p-6 transition-transform duration-300 hover:-translate-y-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "inline-flex size-11 items-center justify-center rounded-xl border border-border",
												style: { backgroundImage: "var(--gradient-surface)" },
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-brand-cyan transition-colors group-hover:text-brand-green" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-5 font-display text-lg font-semibold uppercase tracking-wide",
												children: a.t
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm text-muted-foreground",
												children: a.d
											})
										]
									})
								}, a.t);
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "capabilities",
					className: "scroll-mt-24 border-y border-border bg-secondary/20 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Platform capabilities",
							title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"ONE PLATFORM.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-gradient-brand",
									children: "MULTIPLE POSSIBILITIES."
								})
							] }),
							copy: "Six capability areas that operate as one connected digital ecosystem — not six unrelated tools."
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative mt-12",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3",
								children: capabilities.map((c, i) => {
									const Icon = c.icon;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
										as: "li",
										delay: i * 70,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "surface-panel h-full p-6",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-brand-green" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-display text-base font-semibold uppercase tracking-wide",
													children: c.t
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 text-sm leading-relaxed text-muted-foreground",
												children: c.d
											})]
										})
									}, c.t);
								})
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
								eyebrow: "Architecture",
								title: "FROM PHYSICAL SITE TO INTELLIGENT ACTION.",
								copy: "A continuous pipeline that carries data from the physical world into intelligence and back into action."
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-12 grid gap-4 lg:grid-cols-5",
								children: architecture.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									delay: i * 80,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "surface-panel relative h-full p-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-display text-sm text-brand-cyan",
												children: String(i + 1).padStart(2, "0")
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 font-display text-lg font-semibold",
												children: a.t
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm text-muted-foreground",
												children: a.d
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "absolute inset-x-6 bottom-0 h-px",
												style: {
													backgroundImage: "var(--gradient-brand)",
													opacity: .55
												}
											})
										]
									})
								}, a.t))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
								viewBox: "0 0 1200 40",
								className: "mt-6 w-full",
								"aria-hidden": true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "20",
									y1: "20",
									x2: "1180",
									y2: "20",
									stroke: "url(#connGrad)",
									strokeWidth: "2",
									className: "flow-line"
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "powertwinx",
					className: "scroll-mt-24 border-y border-border bg-secondary/20 py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
								eyebrow: "The ecosystem",
								title: "FROM THE GRID TO THE SITE.",
								copy: "PowerTwinX™ and HubTwinX™ are two connected halves of one digital journey."
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 100,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: grid_to_site_default,
									alt: "Energy journey from generation and transmission through the transformer and smart meter into a digitally connected building",
									loading: "lazy",
									width: 1920,
									height: 768,
									className: "mt-12 w-full rounded-2xl border border-border"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 grid gap-5 lg:grid-cols-[1fr_auto_1fr] lg:items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "surface-panel h-full p-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: "/logo-ptx.png",
												alt: "PowerTwinX",
												className: "h-7 w-auto object-contain"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-3 font-display text-xl font-semibold",
												children: "The digital twin of the power network"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
												className: "mt-5 space-y-2 text-sm text-muted-foreground",
												children: [
													"Generation",
													"Transmission",
													"Distribution",
													"Transformer",
													"Smart Meter"
												].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
													className: "rounded-lg border border-border bg-secondary/30 px-4 py-2.5",
													children: s
												}, s))
											})
										]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
										delay: 80,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-center py-4 lg:h-full lg:flex-col",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hidden h-full w-px bg-border lg:block" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full px-5 py-2 font-display text-xs tracking-[0.24em] text-primary-foreground",
													style: { backgroundImage: "var(--gradient-brand)" },
													children: "THE METER"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hidden h-full w-px bg-border lg:block" })
											]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
										delay: 140,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "surface-panel h-full p-6",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
													src: "/hubtwinx.png",
													alt: "HubTwinX",
													className: "h-7 w-auto object-contain"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-3 font-display text-xl font-semibold",
													children: "The digital twin of the end-user site"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
													className: "mt-5 space-y-2 text-sm text-muted-foreground",
													children: [
														"Meter",
														"Site",
														"Assets",
														"Equipment",
														"Energy",
														"Intelligence",
														"Control"
													].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
														className: "rounded-lg border border-border bg-secondary/30 px-4 py-2.5",
														children: s
													}, s))
												})
											]
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								delay: 120,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mx-auto mt-12 max-w-4xl text-center font-display text-xl leading-snug sm:text-3xl",
									children: [
										"TOGETHER, THEY CONNECT THE DIGITAL JOURNEY FROM",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-gradient-brand",
											children: "POWER SOURCE TO POINT OF CONSUMPTION."
										})
									]
								})
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-7xl px-5 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							eyebrow: "Why HubTwinX",
							title: "WHY HUBTWINX?"
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
							children: [whyItems.map((w, i) => {
								const Icon = w.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									as: "li",
									delay: i * 60,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "surface-panel h-full p-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-6 text-brand-cyan" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-5 font-display text-lg font-semibold uppercase tracking-wide",
												children: w.t
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm text-muted-foreground",
												children: w.d
											})
										]
									})
								}, w.t);
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
								as: "li",
								delay: 420,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex h-full flex-col justify-center rounded-2xl p-6 text-primary-foreground",
									style: { backgroundImage: "var(--gradient-brand)" },
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 font-display text-lg font-semibold leading-snug",
										children: "What exists physically, exists digitally."
									})]
								})
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "about",
					className: "relative scroll-mt-24 isolate overflow-hidden py-24 sm:py-32",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: vision_default,
							alt: "Aerial view of an urban and industrial landscape overlaid with a digital network mesh at dusk",
							loading: "lazy",
							width: 1920,
							height: 912,
							className: "absolute inset-0 -z-20 size-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							"aria-hidden": true,
							className: "absolute inset-0 -z-10",
							style: { background: "linear-gradient(180deg, var(--bg-gradient-top), var(--bg-gradient-bottom))" }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto max-w-4xl px-5 text-center lg:px-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: "Our vision"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "mt-5 font-display text-4xl font-bold leading-[1.02] sm:text-6xl",
									children: ["MAKE EVERY SITE ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gradient-brand",
										children: "INTELLIGENT."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-7 text-lg leading-relaxed text-muted-foreground",
									children: "We believe the future of buildings, industries and infrastructure is not simply connected. It is understood."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-lg leading-relaxed text-muted-foreground",
									children: "HubTwinX aims to create a digital representation of every important element of a site — allowing people and organizations to see, understand, optimize and control their physical environment through one intelligent digital interface."
								})
							] })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "contact",
					className: "scroll-mt-24 border-t border-border py-20 sm:py-28",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto max-w-5xl px-5 text-center lg:px-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/hubtwinx.png",
								alt: "HubTwinX",
								width: 320,
								height: 85,
								className: "mx-auto h-12 w-auto",
								loading: "lazy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-9 font-display text-3xl font-bold leading-[1.05] sm:text-5xl",
								children: [
									"READY TO SEE YOUR ENTIRE HUB",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gradient-brand",
										children: "DIFFERENTLY?"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-lg text-muted-foreground",
								children: "Discover how HubTwinX can create a Digital Twin of your facility."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-9 flex flex-wrap justify-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:info@enerspacetechnology.com?subject=HubTwinX%20Demo%20Request",
									className: "inline-flex items-center gap-2 rounded-full px-8 py-4 font-semibold text-primary-foreground transition-transform duration-300 hover:scale-[1.03]",
									style: { backgroundImage: "var(--gradient-brand)" },
									children: ["BOOK A DEMO ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#platform",
									className: "inline-flex items-center rounded-full border border-border px-8 py-4 font-semibold transition-colors hover:border-primary/60 hover:bg-secondary/50",
									children: "EXPLORE HUBTWINX"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-10 font-display text-sm tracking-[0.16em] text-muted-foreground",
								children: "YOUR ENTIRE HUB. ONE DIGITAL VIEW. EVERYTHING AT YOUR FINGERTIPS."
							})
						] })
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "border-t border-border bg-secondary/20 py-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-[1.4fr_1fr] lg:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/hubtwinx.png",
							alt: "HubTwinX",
							width: 240,
							height: 64,
							loading: "lazy",
							className: "h-9 w-auto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-md text-sm text-muted-foreground",
							children: "Your Entire Hub. One Digital View. Everything at Your Fingertips."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-sm text-muted-foreground",
							children: [
								"Developed by",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: "EnerSpace Technology LLP"
								})
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						"aria-label": "Footer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "eyebrow",
							children: "Navigation"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 grid gap-2 sm:grid-cols-2",
							children: [
								["Home", "#top"],
								["What is HubTwinX", "#platform"],
								["Capabilities", "#capabilities"],
								["Technology", "#technology"],
								["Applications", "#applications"],
								["PowerTwinX + HubTwinX", "#powertwinx"],
								["Contact", "#contact"]
							].map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href,
								className: "text-sm text-muted-foreground transition-colors hover:text-foreground",
								children: label
							}) }, href))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto mt-10 max-w-7xl border-t border-border px-5 pt-6 text-xs text-muted-foreground lg:px-8",
					children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" EnerSpace Technology LLP. HubTwinX™ and PowerTwinX™ are product names of EnerSpace Technology LLP."
					]
				})]
			})
		]
	});
}
//#endregion
export { LightHubTwinX as component };
