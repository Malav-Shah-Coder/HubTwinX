globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"26ac-5GnFa5ERb/haHTYUdO6um5bAdC4\"",
		"mtime": "2026-09-05T13:20:52.564Z",
		"size": 9900,
		"path": "../public/favicon.png"
	},
	"/hubtwinx.png": {
		"type": "image/png",
		"etag": "\"1c498-8dFA11mC164zPOdN45I8gT6HKlA\"",
		"mtime": "2026-09-05T13:08:16.849Z",
		"size": 115864,
		"path": "../public/hubtwinx.png"
	},
	"/logo-ptx.png": {
		"type": "image/png",
		"etag": "\"667a-v710bwPNifGZkgw/taXCTPpwrcM\"",
		"mtime": "2026-09-03T15:17:00.443Z",
		"size": 26234,
		"path": "../public/logo-ptx.png"
	},
	"/assets/energy-ecosystem-NewX1QMe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5e1d-jUSm8ll/lRf9qyCB8CaXOfRxlU8\"",
		"mtime": "2026-09-14T17:10:23.086Z",
		"size": 24093,
		"path": "../public/assets/energy-ecosystem-NewX1QMe.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-05T13:20:52.584Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/control-room-Dg7REq6t.jpg": {
		"type": "image/jpeg",
		"etag": "\"2c15b-VmeXvniHBcz+3CvHp9Ri09k2VUk\"",
		"mtime": "2026-09-14T17:10:23.087Z",
		"size": 180571,
		"path": "../public/assets/control-room-Dg7REq6t.jpg"
	},
	"/logo-vr.png": {
		"type": "image/png",
		"etag": "\"59c0a-YJDaY66GkcuvD8JN2pgDGAWRsb8\"",
		"mtime": "2026-09-05T07:22:20.250Z",
		"size": 367626,
		"path": "../public/logo-vr.png"
	},
	"/assets/light-DO74VBe1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6f61-UII1izu+dNxRYQLjGxq/Qgo+DhM\"",
		"mtime": "2026-09-14T17:10:23.086Z",
		"size": 28513,
		"path": "../public/assets/light-DO74VBe1.js"
	},
	"/assets/index-P02nZ65f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54f54-DQ4J0psthMW21m9fEQtHOTA4j0c\"",
		"mtime": "2026-09-14T17:10:23.085Z",
		"size": 347988,
		"path": "../public/assets/index-P02nZ65f.js"
	},
	"/assets/energy-ecosystem-B04hnANP.jpg": {
		"type": "image/jpeg",
		"etag": "\"197e1-clXqCZjHNwsP41Ooy+vD6NteSeU\"",
		"mtime": "2026-09-14T17:10:23.087Z",
		"size": 104417,
		"path": "../public/assets/energy-ecosystem-B04hnANP.jpg"
	},
	"/assets/routes-B4KHeOx2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6f5e-04RlvbRalWCT4X5/XPZbXYjgopU\"",
		"mtime": "2026-09-14T17:10:23.086Z",
		"size": 28510,
		"path": "../public/assets/routes-B4KHeOx2.js"
	},
	"/assets/grid-to-site-f19cek5J.jpg": {
		"type": "image/jpeg",
		"etag": "\"1d086-h/18eFgOCv4RrYw2Grh7LVNF9A4\"",
		"mtime": "2026-09-14T17:10:23.089Z",
		"size": 118918,
		"path": "../public/assets/grid-to-site-f19cek5J.jpg"
	},
	"/assets/styles-R8xwiKaw.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14826-L2AyDA7KFEVqueYUMo2QduPV8Go\"",
		"mtime": "2026-09-14T17:10:23.094Z",
		"size": 84006,
		"path": "../public/assets/styles-R8xwiKaw.css"
	},
	"/assets/industrial-twin-CVtcagBz.jpg": {
		"type": "image/jpeg",
		"etag": "\"26dec-/vLlPP8lQXBBruYutrMM7pWyI2A\"",
		"mtime": "2026-09-14T17:10:23.091Z",
		"size": 159212,
		"path": "../public/assets/industrial-twin-CVtcagBz.jpg"
	},
	"/assets/hero-digital-twin-BHPgabjV.jpg": {
		"type": "image/jpeg",
		"etag": "\"49c86-LFnSkYr/NXZjPBxxUVrVLG65qck\"",
		"mtime": "2026-09-14T17:10:23.089Z",
		"size": 302214,
		"path": "../public/assets/hero-digital-twin-BHPgabjV.jpg"
	},
	"/assets/vision-DA5mqRIz.jpg": {
		"type": "image/jpeg",
		"etag": "\"489cb-gM6VfQby38SmD0WlAAmHzbo4tQ8\"",
		"mtime": "2026-09-14T17:10:23.099Z",
		"size": 297419,
		"path": "../public/assets/vision-DA5mqRIz.jpg"
	},
	"/Logo.png": {
		"type": "image/png",
		"etag": "\"11bcd5-JdT56FbwcwCQnjnsD2WgoGWuGT0\"",
		"mtime": "2026-09-05T06:25:37.028Z",
		"size": 1162453,
		"path": "../public/Logo.png"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_7QXpG4 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_7QXpG4
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
