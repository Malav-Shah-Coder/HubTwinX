//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-OFm-jI4E.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "E:/ERNS/HobTwinX/Website/site-intelligence-hub-main/src/routes/__root.tsx",
		children: ["/", "/light"],
		preloads: ["/assets/index-P02nZ65f.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-P02nZ65f.js"
		} }]
	},
	"/": {
		filePath: "E:/ERNS/HobTwinX/Website/site-intelligence-hub-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B4KHeOx2.js", "/assets/energy-ecosystem-NewX1QMe.js"]
	},
	"/light": {
		filePath: "E:/ERNS/HobTwinX/Website/site-intelligence-hub-main/src/routes/light.tsx",
		children: void 0,
		preloads: ["/assets/light-DO74VBe1.js", "/assets/energy-ecosystem-NewX1QMe.js"]
	}
} });
//#endregion
export { tsrStartManifest };
